package com.smok95.jkqrcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
