# jkqrcode-reader
Android QR Code/Barcode Reader

<a href="https://play.google.com/store/apps/details?id=com.smok95.jkqrcode"><img src="https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png" height="75"></a>

![alt tag](https://raw.githubusercontent.com/smok95/jkqrcode-reader/master/etc/jkqrcode.gif)
